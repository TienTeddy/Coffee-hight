﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nhom102_ManagerCoffee.Common
{
    public static class CommonConstants
    {
        public static string ACCOUNT_SESSION = "ACCOUNT_SESSION";
    }
}